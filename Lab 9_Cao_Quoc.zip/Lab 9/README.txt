Quoc Cao
EE104
Lab#9

Reference: Laboratory Assignment 9

***GitHub: https://github.com/Quoccao1/Lab9.git
***Video link for the video demonstration: https://drive.google.com/file/d/1M0IN0GO2OWNwLnXfN7g9Um9WhGwZ7Xbt/view?usp=share_link 
***Video link for the Dance Challenge game: https://drive.google.com/file/d/1NXe7_8jxDumKt9vX148HkDq1stWx22P9/view?usp=share_link 


***MAKE SURE THAT THE FOLLOWING PYTHON MODULES ARE INSTALLED***
import pgzrun
import pygame
import pgzero
from pgzero.builtins import Actor
from random import randint
import smtplib, ssl
import time
from sys import exit

***Data Science – Risk Factor Identification***
-Download a CSV file from this website: http://www.creditriskanalytics.net/datasets-private2.html 
-Analyze and identify risk indicators contributing to loan defaults and report to the bank
-Add the CSV file to python
-Run the code to create a new column

***Data Science - Trend Prediction***
-This page has datasets for Santa Clara County: https://data.sccgov.org/browse?category=COVID-19
-Download a dataset for six months( from January to June) 
-Include the CVS file in the Python code
-Run the code to plot a prediction displaying data from January through December.
-Download the same dataset from January to December
-Plot a second curve to show the reality and compare to the prediction plot in Python.

***Dance Challenge***
-Install all of the necessary libraries and modules for the game
-Add second player
-Change the music of the game
-Run the code and enjoy the game
